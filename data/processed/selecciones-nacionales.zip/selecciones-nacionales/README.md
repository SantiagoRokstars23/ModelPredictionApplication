# Módulo: Selecciones Nacionales

**Directorio:** `data/processed/selecciones-nacionales/`

**Versión:** 1.7.0

**Estado:** Activo (esquema aprobado; `selecciones.csv`, `competiciones.csv`, `estadios.csv`, `arbitros.csv`, `torneos.csv`, `partidos.csv` y `estadisticas_partido.csv` poblados con datos reales, resto de entidades pendientes)

---

# Objetivo

Este módulo constituye la primera implementación de la Base de Conocimiento (`docs/05-Base-de-Conocimiento.md`) para el dominio de selecciones nacionales de fútbol.

Define 11 entidades, cada una en su propio archivo CSV, siguiendo el esquema aprobado en la Misión 001.

---

# Decisiones arquitectónicas aplicadas

1. **Principio de Justificación de Datos**: cada campo de cada entidad está justificado explícitamente en este documento (ver tablas por entidad), conforme a `docs/05-Base-de-Conocimiento.md`.
2. **Ubicación**: se mantiene `data/processed/selecciones-nacionales/`.
3. **`campeon_id_seleccion` eliminado** de `torneos`: es un dato derivado (se obtiene consultando el partido con `fase = final` en `partidos.csv`), nunca se almacena para evitar duplicación.
4. **Sin estadísticas individuales de jugador** en esta misión (goles, asistencias, minutos jugados por jugador y partido). Queda explícitamente diferido a una misión futura.
5. **`id_torneo` nunca nulo**: se define la competición `Amistosos Internacionales` y un torneo contenedor por año calendario para partidos amistosos (ver sección dedicada más abajo).

---

# Convención: Amistosos Internacionales

Los partidos amistosos no pertenecen a un torneo con fase de grupos ni eliminatorias, pero **todo partido debe tener un `id_torneo` válido** para preservar la integridad referencial del modelo (regla aplicada en esta misión: evitar `id_torneo` nulo).

Se resuelve de la siguiente forma:

- Se crea **una única competición permanente** en `competiciones.csv`: `Amistosos Internacionales` (tipo `amistoso`, organizada por FIFA). No es periódica (`periodicidad_anios` queda vacío) porque no sigue un ciclo fijo.
- Se crea **un torneo contenedor por año calendario** en `torneos.csv` (ej. `TOR-2026-AMISTOSOS`, `fecha_inicio: 2026-01-01`, `fecha_fin: 2026-12-31`). Todo amistoso jugado ese año se asocia a ese `id_torneo`.
- La sede no es única (los amistosos se juegan en estadios distintos), por lo que `paises_organizadores` para estos torneos contenedor queda como `N/A (sede variable, ver partidos.id_estadio)`.
- `numero_selecciones_participantes` queda vacío para estos torneos, ya que no existe un conjunto fijo de participantes.

**Regla operativa:** al registrar el primer amistoso de un nuevo año calendario, se debe crear primero la fila correspondiente en `torneos.csv` (`TOR-<año>-AMISTOSOS`) antes de insertar el partido. Esta misión ya crea la fila para el año en curso (2026) como ejemplo del patrón.

**Nota de granularidad:** se eligió agrupar por año calendario (no por ventana FIFA de fecha internacional) por simplicidad, siguiendo la regla del proyecto de no incrementar la complejidad sin evidencia de que mejora el modelo (`CLAUDE.md`). Si en el futuro se demuestra que la granularidad por ventana FIFA aporta valor predictivo, se documentará como mejora en `models/` antes de modificar este esquema.

---

# Estado de los archivos

`selecciones.csv` contiene 54 registros reales: 40 del Top 40 FIFA (Misión 002) más 14 incorporadas en la Misión **MS-019** — únicamente las selecciones cuya ausencia fue demostrada empíricamente en `MS-018` como bloqueo real de 19 partidos ya investigados (Chile, Perú, Venezuela, Bolivia, Paraguay, Costa Rica, Serbia, Albania, Georgia, Eslovaquia, Eslovenia, Grecia, Finlandia, República de Irlanda) — no una ampliación general del catálogo. Fuentes y limitaciones detalladas en `CHANGELOG.md` (entrada `MS-019`). `competiciones.csv` contiene 11 registros reales: la fila de catálogo `Amistosos Internacionales` (Misión 001) más 10 competiciones internacionales pobladas en la Misión 006. `torneos.csv` contiene 13 registros reales: la fila de referencia `TOR-2026-AMISTOSOS` (Misión 001) más 12 ediciones reales incorporadas en la Misión MS-015 — la edición más reciente ya oficialmente celebrada de cada una de las 8 competiciones cubiertas por el brief de esa misión (Copa Mundial FIFA 2026; Eurocopa 2024; Copa América 2024; UEFA Nations League 2024-25; CONCACAF Gold Cup 2025; Copa Asiática 2023; Copa Africana de Naciones 2025), y 5 filas para "Eliminatorias Mundial FIFA" (una por confederación — CONMEBOL, UEFA, CONCACAF, AFC, CAF — dado que cada proceso clasificatorio real tiene sede, formato y calendario propios, sin un formato único global que agrupe a las seis confederaciones). Quedan pendientes las ediciones de OFC Nations Cup y Finalissima (`COMP-000010`/`COMP-000011`, fuera del alcance del brief de `MS-015`) y la clasificatoria OFC hacia el Mundial 2026. Fuentes y limitaciones detalladas en `CHANGELOG.md` (entrada `MS-015`). `estadios.csv` contiene 65 registros reales: 32 de la Misión MS-013 (un estadio principal por cada una de 32 de las 40 selecciones ya catalogadas) más 33 de la Misión MS-017 (sedes de **torneo** — neutrales/anfitrionas — para la Copa Mundial FIFA 2026, la Eurocopa 2024, la Copa América 2024, la UEFA Nations League 2024-25 y las Eliminatorias CONMEBOL, ver detalle en la entidad `estadios.csv` más abajo), ambas poblados siguiendo estrictamente el protocolo de ingesta (`docs/38-Protocolo-Oficial-Ingesta-Datos.md`). Quedan pendientes 8 selecciones sin estadio de sede habitual (`NOR`, `UKR`, `PAN`, `RUS`, `WAL`, `HUN`, `CZE` — `ECU` quedó cubierto indirectamente por `MS-017` vía su sede de Eliminatorias) y cualquier estadio adicional usado por amistosos o por torneos fuera del alcance de `MS-017` (CONCACAF Gold Cup 2025, Copa Asiática 2023, Copa Africana de Naciones 2025). Fuentes y limitaciones detalladas en `CHANGELOG.md` (entradas `MS-013` y `MS-017`) y `docs/00-Project-Tracker.md`. `arbitros.csv` contiene 51 registros reales (Misión MS-014): el panel completo de árbitros principales (no asistentes, no VAR) designados oficialmente por FIFA para la Copa Mundial FIFA 2026, cubriendo las seis confederaciones (AFC, CAF, CONCACAF, CONMEBOL, OFC, UEFA) — fuente primaria, `inside.fifa.com` ("Match officials appointed for FIFA World Cup 2026"), con el desglose nominal por confederación verificado contra la tabla ya organizada de Wikipedia. Fuentes y limitaciones detalladas en `CHANGELOG.md` (entrada `MS-014`). `partidos.csv` contiene 32 registros reales y `estadisticas_partido.csv` contiene 53 registros reales (Misión **MS-018**): reevaluación de los 51 partidos candidatos ya investigados en `MS-016` contra las FK ampliadas por `MS-017` (65 estadios), sin investigar ningún partido nuevo. De los 51 candidatos, 32 pasaron todas las validaciones (Eurocopa 2024: 13; Copa América 2024: 6; UEFA Nations League 2024-25: 6; Eliminatorias CONMEBOL: 7); 19 siguen bloqueados, todos por la misma causa (rival real ausente de `selecciones.csv`: Chile, Perú, Venezuela, Bolivia, Paraguay, Costa Rica, Serbia, Albania, Georgia, Eslovaquia, Eslovenia, Grecia, Finlandia, República de Irlanda). De las 64 filas posibles de `estadisticas_partido.csv` (32 partidos × 2 equipos), 11 quedaron sin escribir por no tener ninguna estadística verificable en fuente autorizada (ni siquiera tarjetas) — ver `CHANGELOG.md` (entrada `MS-018`) para el detalle completo por partido. El resto de los CSV de este módulo (`jugadores`, `convocatorias`, `lesiones`, `cuotas`) siguen conteniendo únicamente la fila de encabezado — cumpliendo la regla "nunca inventar datos" mientras no exista una fuente verificada.

---

# Entidades

## 1. `selecciones.csv`

| Campo | Tipo | Clave | Justificación |
|---|---|---|---|
| `id_seleccion` | STRING(3) | PK | Integridad referencial: identificador único usado por todas las entidades relacionadas |
| `nombre_pais` | STRING | | Identificación legible del equipo en reportes de predicción (`docs/08-predicciones.md`) |
| `nombre_federacion` | STRING | | Trazabilidad de la fuente oficial (`docs/05-Base-de-Conocimiento.md`: "toda fuente deberá ser identificable y verificable") |
| `confederacion` | ENUM | | Contextualiza viajes intercontinentales (Factores Externos, `docs/03-Variables.md`) y agrupación de clasificatorias |
| `ranking_fifa_actual` | INTEGER | | Proxy de fuerza general, usado como prior en `engine/03-Poisson.md` y `engine/05-Confidence.md` |
| `ranking_fifa_fecha` | DATE | | Vigencia del dato (`docs/05-Base-de-Conocimiento.md`: "Calidad de Datos → fecha de actualización") |
| `seleccionador_actual` | STRING | | Insumo cualitativo de Compatibilidad Táctica (Variable 005, `docs/03-Variables.md`) |
| `activa` | BOOLEAN | | Integridad del modelo: excluye federaciones inactivas de la predicción |

**Relaciones:** referenciada por `jugadores`, `convocatorias`, `partidos`, `estadisticas_partido`.
**Restricciones:** `id_seleccion` único, 3 letras mayúsculas; `ranking_fifa_actual` > 0; `ranking_fifa_fecha` no futura.
**Datos poblados en la Misión MS-019:** 14 selecciones reales adicionales (`CHI`, `PER`, `VEN`, `BOL`, `PAR`, `CRC`, `SRB`, `ALB`, `GEO`, `SVK`, `SVN`, `GRE`, `FIN`, `IRL`) — alcance controlado, no una ampliación general del Top 40 FIFA: únicamente las selecciones cuya falta bloqueaba, con evidencia empírica de `MS-018`, la incorporación de partidos reales ya investigados en `MS-016`. `ranking_fifa_fecha = 2026-07-20` (edición FIFA distinta a la de las 40 selecciones originales, `2026-06-11` — ambas vigentes en sus respectivas fechas de captura, sin corregirse entre sí). **Limitación documentada:** `seleccionador_actual` de Serbia, Georgia, Eslovenia y Grecia proviene de una única fuente secundaria (infobox de Wikipedia del equipo nacional), sin segunda fuente independiente de verificación cruzada — confianza moderada, no descartado por seguir el mismo criterio ya usado en `MS-013` (Wikipedia como respaldo cuando la fuente oficial de la federación resultó inaccesible), pero sí más débil que el resto de campos de esta misión (ranking FIFA/confederación, verificados por partida doble: fecha oficial confirmada en `inside.fifa.com`, valor numérico cruzado con Wikipedia).

---

## 2. `jugadores.csv`

| Campo | Tipo | Clave | Justificación |
|---|---|---|---|
| `id_jugador` | STRING | PK | Integridad referencial (`convocatorias`, `lesiones`) |
| `nombre_completo` | STRING | | Trazabilidad |
| `nombre_conocido` | STRING | | Legibilidad en reportes |
| `fecha_nacimiento` | DATE | | Proxy de Fatiga/Calidad de Plantilla (edad, Variable 007/008) |
| `posicion_principal` | ENUM | | Insumo de Compatibilidad Táctica (Variable 005) |
| `pie_habil` | ENUM | | Insumo secundario de Compatibilidad Táctica |
| `altura_cm` | INTEGER | | Insumo de perfil físico en Compatibilidad Táctica (ej. juego aéreo) |
| `id_seleccion` | STRING | FK → `selecciones` | Integridad referencial; insumo de Disponibilidad de Plantilla |
| `club_actual` | STRING | | Contexto de carga competitiva, insumo de Fatiga (Variable 007) |
| `activo_seleccion` | BOOLEAN | | Integridad: evita convocatorias inválidas |

**Restricciones:** `id_jugador` único e inmutable; `fecha_nacimiento` no futura; un jugador solo puede tener una `id_seleccion` activa a la vez.

---

## 3. `convocatorias.csv`

| Campo | Tipo | Clave | Justificación |
|---|---|---|---|
| `id_convocatoria` | STRING | PK | Integridad referencial/trazabilidad |
| `id_torneo` | STRING | FK → `torneos` | Reconstruye Disponibilidad de Plantilla (Variable 006) por torneo |
| `id_seleccion` | STRING | FK → `selecciones` | Idem |
| `id_jugador` | STRING | FK → `jugadores` | Idem |
| `dorsal` | INTEGER | | Trazabilidad/identificación oficial |
| `posicion_convocatoria` | ENUM | | Refina Compatibilidad Táctica para el torneo específico |
| `fecha_convocatoria` | DATE | | Vigencia del dato; insumo de Estado Psicológico (tensión por convocatoria tardía) |
| `estado_convocatoria` | ENUM | | Insumo directo de Disponibilidad de Plantilla (bajas antes/durante el torneo) |

**Restricciones:** único (`id_torneo`, `id_seleccion`, `id_jugador`); único (`id_torneo`, `id_seleccion`, `dorsal`).

---

## 4. `partidos.csv`

| Campo | Tipo | Clave | Justificación |
|---|---|---|---|
| `id_partido` | STRING | PK | Integridad referencial: entidad central del sistema |
| `id_torneo` | STRING | FK → `torneos` (nunca nulo) | Insumo de Rendimiento en el Torneo (Variable 002) y de Índice de Caos |
| `id_seleccion_local` | STRING | FK → `selecciones` | Insumo de Localía (Variable 009) |
| `id_seleccion_visitante` | STRING | FK → `selecciones` | Idem |
| `id_estadio` | STRING | FK → `estadios` | Insumo de Factores Externos (altitud, clima) |
| `id_arbitro` | STRING | FK → `arbitros` | Insumo de Factores Externos (Variable 012) |
| `fecha` | DATE | | Insumo de Forma Reciente (Variable 001) y Fatiga (descanso entre partidos) |
| `hora_local` | STRING | | Insumo secundario de Factores Externos (calor/humedad según franja horaria) |
| `fase` | ENUM | | Insumo de Índice de Caos (`engine/04-Chaos-Index.md`) y Estado Psicológico |
| `jornada` | INTEGER | | Contextualiza Rendimiento en el Torneo |
| `goles_local` | INTEGER | | Resultado oficial, base de `docs/09-Auditoria.md` |
| `goles_visitante` | INTEGER | | Idem |
| `estado_partido` | ENUM | | Filtra partidos válidos para el cálculo de variables |
| `asistencia` | INTEGER | | Insumo secundario de Estado Psicológico/presión ambiental |

**Campo excluido:** `resultado_final`/`ganador` — se deriva de `goles_local` vs. `goles_visitante`.
**Restricciones:** `id_seleccion_local` ≠ `id_seleccion_visitante`; goles solo se completan si `estado_partido = finalizado`; `jornada` obligatorio solo si `fase = fase_grupos`; `id_torneo` es **obligatorio siempre** (ver convención de Amistosos Internacionales).
**Formato de `id_partido` (fijado en `MS-018`, sin precedente previo):** `PAR-NNNNNN` (6 dígitos), mismo patrón que `EST-NNNNNN`/`ARB-NNNNNN`/`COMP-NNNNNN`.
**Valores de `fase` (literales, sin ENUM formalizado, hallazgo heredado de `docs/38`) usados en `MS-018`:** `fase_grupos`, `octavos_final`, `cuartos_final`, `semifinal`, `tercer_puesto`, `final` (torneos con eliminación directa) y `eliminatoria` (Eliminatorias Mundial FIFA — fase de liga todos-contra-todos, sin equivalente de "grupo" ni "eliminación directa"; usa `jornada` con el número de fecha aunque la restricción del esquema no lo exija fuera de `fase_grupos`, por ser informativo y no estar prohibido).
**Hallazgo de `MS-018`, no resuelto:** ninguna columna registra el resultado de una tanda de penales. 5 de los 32 partidos poblados se definieron en penales tras empate en el marcador de 90+prórroga (`PAR-000016`, `PAR-000017`, `PAR-000020`, `PAR-000024`, `PAR-000022`) — `goles_local`/`goles_visitante` reflejan fielmente el marcador de campo (nunca los penales, que no son goles de juego), pero esto significa que el campo derivado "campeón" (`torneos.campeon_id_seleccion`, obtenido de la fila con `fase = final`) **no es calculable con precisión** para un torneo cuya final se decida en penales usando solo `partidos.csv` — afecta ya a `PAR-000022` (final de la Nations League 2024-25, Portugal 2-2 España, Portugal ganador real por penales 5-3). Se documenta la limitación en vez de agregar una columna nueva (fuera del alcance de `MS-018`, que no autoriza modificar el esquema).

---

## 5. `estadisticas_partido.csv`

| Campo | Tipo | Clave | Justificación |
|---|---|---|---|
| `id_estadistica_partido` | STRING | PK | Integridad referencial |
| `id_partido` | STRING | FK → `partidos` | Relación obligatoria |
| `id_seleccion` | STRING | FK → `selecciones` | Idem |
| `xg` | DECIMAL | | Insumo directo de Potencial Ofensivo (Variable 003) y `engine/01-Offensive-Strength.md` |
| `posesion_pct` | DECIMAL | | Insumo de Compatibilidad Táctica (Variable 005) |
| `disparos_totales` | INTEGER | | Insumo directo de Potencial Ofensivo (Variable 003) |
| `disparos_al_arco` | INTEGER | | Idem |
| `corners` | INTEGER | | Proxy secundario de dominio ofensivo |
| `faltas_cometidas` | INTEGER | | Insumo de Índice de Caos (indisciplina como imprevisibilidad) |
| `tarjetas_amarillas` | INTEGER | | Idem, y base para futura Disponibilidad de Plantilla por acumulación |
| `tarjetas_rojas` | INTEGER | | Idem |
| `pases_completados` | INTEGER | | Insumo de Compatibilidad Táctica (estilo de posesión/juego directo) |
| `precision_pases_pct` | DECIMAL | | Idem |

**Campo excluido:** `xga` — es idéntico al `xg` del rival en el mismo `id_partido`; se obtiene con un self-join, nunca se duplica.
**Restricciones:** único (`id_partido`, `id_seleccion`); `posesion_pct` 0-100; `disparos_al_arco` ≤ `disparos_totales`.
**Formato de `id_estadistica_partido` (fijado en `MS-018`, sin precedente previo):** `ESTP-NNNNNN` (6 dígitos), mismo patrón que `PAR-NNNNNN`/`EST-NNNNNN`.
**Datos poblados en `MS-018`:** 53 de 64 filas posibles (32 partidos × 2 equipos). Los campos `xg`, `pases_completados` y `precision_pases_pct` quedan vacíos en la mayoría de los partidos de Eurocopa 2024/Nations League 2024-25 (no disponibles en ninguna fuente autorizada accedida — UEFA.com bloqueó el acceso automatizado) y en todos los de Eliminatorias CONMEBOL (AFA/CBF no publican estas métricas en sus crónicas oficiales) — nunca se estimaron ni interpolaron. Las 11 filas equipo-partido sin ninguna estadística verificable (ni tarjetas) se dejaron sin escribir en vez de crear una fila vacía sin valor informativo: Uruguay (`PAR-000026`), ambos equipos de `PAR-000027`/`PAR-000028`/`PAR-000030`/`PAR-000031`/`PAR-000032` — ver `CHANGELOG.md` para el detalle completo.

---

## 6. `lesiones.csv`

| Campo | Tipo | Clave | Justificación |
|---|---|---|---|
| `id_lesion` | STRING | PK | Integridad referencial |
| `id_jugador` | STRING | FK → `jugadores` | Insumo de Disponibilidad de Plantilla (Variable 006) |
| `tipo_lesion` | STRING | | Calibra el impacto real en Disponibilidad |
| `gravedad` | ENUM | | Idem |
| `fecha_inicio` | DATE | | Permite calcular disponibilidad exacta por partido/convocatoria |
| `fecha_estimada_retorno` | DATE | | Idem |
| `fecha_retorno_real` | DATE | | Idem |
| `id_partido_origen` | STRING | FK → `partidos` (opcional) | Trazabilidad del origen de la lesión |
| `estado` | ENUM | | Filtra lesiones activas vs. resueltas |
| `fuente` | STRING | | Regla "nunca inventar datos": la fuente debe ser verificable |

**Campo excluido:** `id_seleccion` — se deriva de `jugadores.id_jugador`.
**Restricciones:** `fecha_estimada_retorno` ≥ `fecha_inicio`; `fecha_retorno_real` solo si `estado = recuperado`; `fuente` obligatoria.

---

## 7. `cuotas.csv`

| Campo | Tipo | Clave | Justificación |
|---|---|---|---|
| `id_cuota` | STRING | PK | Integridad referencial |
| `id_partido` | STRING | FK → `partidos` | Relación obligatoria |
| `casa_apuestas` | STRING | | Trazabilidad de la fuente |
| `mercado` | ENUM | | Define qué probabilidad de mercado se compara en `engine/06-Expected-Value.md` |
| `seleccion_o_resultado` | STRING | | Idem |
| `cuota_decimal` | DECIMAL | | Insumo directo de `engine/06-Expected-Value.md` |
| `fecha_captura` | DATE+hora | | Las cuotas varían en el tiempo; se necesita la vigente al momento de la predicción |
| `estado_cuota` | ENUM | | Filtra cuotas abiertas de las cerradas/suspendidas |

**Campo excluido:** `probabilidad_implicita` — se calcula en `engine/06-Expected-Value.md`, no es un dato bruto.
**Restricciones:** `cuota_decimal` > 1.00; unicidad real = (`id_partido`, `casa_apuestas`, `mercado`, `seleccion_o_resultado`, `fecha_captura`).

---

## 8. `arbitros.csv`

| Campo | Tipo | Clave | Justificación |
|---|---|---|---|
| `id_arbitro` | STRING | PK | Integridad referencial |
| `nombre_completo` | STRING | | Trazabilidad |
| `nacionalidad` | STRING | | Contexto de Factores Externos (sesgo potencial, solo con evidencia) |
| `confederacion_arbitral` | ENUM | | Calibra la fiabilidad del dato (exigencia distinta por panel) |
| `categoria` | ENUM | | Idem |
| `activo` | BOOLEAN | | Filtra árbitros vigentes |

**Restricciones:** `nombre_completo` obligatorio; `categoria = fifa_internacional` requerido en torneos FIFA/confederación.
**Formato de `id_arbitro` (fijado en `MS-014`, sin precedente previo en este documento):** `ARB-NNNNNN` (6 dígitos), mismo patrón ya usado por `competiciones.csv` (`COMP-NNNNNN`) y `estadios.csv` (`EST-NNNNNN`, `MS-013`).
**Valores de `confederacion_arbitral` (ENUM) usados en `MS-014`:** `AFC`, `CAF`, `CONCACAF`, `CONMEBOL`, `OFC`, `UEFA` — mismos seis códigos de confederación ya usados en `selecciones.csv`/`competiciones.csv` (`confederacion_organizadora` excluye `FIFA` de esta columna específica, a diferencia de `competiciones.csv`: un árbitro pertenece siempre a una única confederación real, nunca a "FIFA" como panel propio — la designación FIFA es la categoría, no la confederación).
**Valores de `categoria` (ENUM) confirmados:** solo `fifa_internacional` está citado textualmente en este documento (ver "Restricciones" arriba) — `MS-014` no formaliza ningún otro valor (hallazgo heredado de `docs/38`, no resuelto).
**Datos poblados en la Misión MS-014:** 51 árbitros reales — ver `CHANGELOG.md` para fuentes y limitaciones completas.

---

## 9. `estadios.csv`

| Campo | Tipo | Clave | Justificación |
|---|---|---|---|
| `id_estadio` | STRING | PK | Integridad referencial |
| `nombre` | STRING | | Trazabilidad/contexto |
| `ciudad` | STRING | | Idem |
| `pais` | STRING | | Idem |
| `capacidad` | INTEGER | | Proxy de Estado Psicológico/presión ambiental |
| `tipo_superficie` | ENUM | | Insumo de Factores Externos (Variable 012: estado del campo) |
| `altitud_metros` | INTEGER | | Insumo directo de Factores Externos (Variable 012: altitud) |
| `techado` | BOOLEAN | | Insumo de Factores Externos (anula la variable clima si es techado) |

**Restricciones:** `capacidad` > 0; `altitud_metros` puede ser negativo.
**Formato de `id_estadio` (fijado en `MS-013`, sin precedente previo en este documento):** `EST-NNNNNN` (6 dígitos), mismo patrón ya usado por `competiciones.csv` (`COMP-NNNNNN`).
**Hallazgo heredado de `MS-012`/`docs/38`, no resuelto en `MS-013`, ampliado en `MS-017`:** el ENUM de `tipo_superficie` nunca fue formalizado en ningún documento — los 32 registros poblados en `MS-013` usan el valor literal `natural`. `MS-017` introduce, sin formalizar tampoco un ENUM (columna sin cambios), dos valores literales adicionales ya necesarios en la práctica: `artificial` (césped artificial permanente, típico de estadios multipropósito NFL/CFL) e `hibrido` (césped natural reforzado con fibra sintética). Sigue sin existir una taxonomía cerrada — cualquier futura misión que agregue estadios deberá seguir usando el valor descriptivo más simple y verificable, sin inventar uno nuevo si alguno de estos tres ya aplica.
**Datos poblados en la Misión MS-013:** 32 estadios reales (uno por selección, para 32 de las 40 ya catalogadas en `selecciones.csv`) — ver `CHANGELOG.md` para fuentes y limitaciones completas.
**Datos poblados en la Misión MS-017:** 33 estadios reales adicionales (`EST-000033` a `EST-000065`) — sedes de **torneo** (neutrales/anfitrionas), a diferencia de los 32 de `MS-013` que son la sede habitual de cada selección. Cubre: los 9 estadios alemanes de la Eurocopa 2024 no catalogados (excluye Allianz Arena, Múnich, ya existente); 16 estadios de la Copa América 2024 (13) y del Mundial FIFA 2026 (13, con solapamiento de 10 con los de Copa América — mismo estadio físico usado por ambos torneos, una sola fila) más 3 exclusivos de Copa América y 3 exclusivos del Mundial, en Estados Unidos, más BC Place (Canadá) y Estadio BBVA/Estadio Akron (México) del Mundial 2026; Estadio Mestalla (Valencia) y Stadion Poljud (Split) de la Nations League 2024-25; y Estadio Monumental Isidro Romero Carbo (Guayaquil — cierra el hueco de Ecuador ya documentado), Arena Fonte Nova (Salvador) y Arena BRB Mané Garrincha (Brasília) de las Eliminatorias CONMEBOL. **Introduce por primera vez los valores `artificial` e `hibrido` en `tipo_superficie`** (columna sin ENUM formalizado desde `MS-012`/`docs/38`, ver hallazgo bajo la entidad `estadios.csv`) — los 32 estadios de `MS-013` eran todos césped natural; varios estadios multipropósito de EE.UU. usan césped artificial permanente con césped natural instalado temporalmente para fútbol (confirmado explícitamente solo para algunos casos, ver `CHANGELOG.md`). Stadion Feijenoord ("De Kuip", Róterdam) quedó **explícitamente omitido**: ninguna fuente consultada ofrece una altitud coherente y citable para Róterdam (ciudad con zonas bajo el nivel del mar, sin un punto de referencia único) — regla de esta misión "ante duda, no incorporar el estadio". Ver `CHANGELOG.md` para fuentes, discrepancias entre proveedores y limitaciones completas por estadio.

---

## 10. `competiciones.csv`

| Campo | Tipo | Clave | Justificación |
|---|---|---|---|
| `id_competicion` | STRING | PK | Integridad referencial: identificador único usado por `torneos.id_competicion` |
| `nombre` | STRING | | Trazabilidad/legibilidad en reportes de predicción |
| `confederacion_organizadora` | ENUM | | Contextualiza el nivel de exigencia esperado (Variable 011, Estado Psicológico/presión competitiva) y el organismo responsable de la fuente oficial de datos |
| `tipo` | ENUM | | Insumo directo de Índice de Caos y de la ponderación por tipo de partido (`docs/02-modelo.md`, Niveles A-D) |
| `periodicidad_anios` | INTEGER | | Contextualiza relevancia competitiva (vacío si la competición no sigue un ciclo fijo, ej. `tipo = amistoso` o `interconfederacion`) |
| `activa` | BOOLEAN | | Filtra competiciones vigentes |

**Restricciones:** `id_competicion` único, formato `COMP-NNNNNN` (6 dígitos); `nombre` único; `periodicidad_anios` > 0 cuando no está vacío.

**Relaciones:** referenciada por `torneos.id_competicion` (FK obligatoria — todo torneo pertenece a exactamente una competición).

**Valores de `confederacion_organizadora` (ENUM):** `FIFA`, `UEFA`, `CONMEBOL`, `CONCACAF`, `AFC`, `CAF`, `OFC` — mismos códigos de confederación usados en `selecciones.csv`. Excepción documentada: `CONMEBOL-UEFA` para competiciones organizadas conjuntamente por dos confederaciones (caso único actual: Finalissima). No se crea un valor genérico "conjunta" para evitar perder trazabilidad de qué organismos específicos participan.

**Valores de `tipo` (ENUM), definidos en esta misión (MS-006):**

| Valor | Significado | Ejemplo |
|---|---|---|
| `amistoso` | Partido bilateral sin fase de grupos ni eliminatoria | Amistosos Internacionales |
| `mundial` | Fase final de la Copa Mundial FIFA | Copa Mundial FIFA |
| `eliminatoria_mundial` | Proceso clasificatorio hacia la Copa Mundial FIFA, organizado por confederación bajo normativa FIFA | Eliminatorias Mundial FIFA |
| `continental` | Torneo de selecciones de una única confederación, formato grupos + eliminación directa | Eurocopa, Copa América, CONCACAF Gold Cup, Copa Asiática, Copa Africana de Naciones, OFC Nations Cup |
| `liga_naciones` | Formato de liga con ascenso/descenso entre divisiones, seguido de una fase final | UEFA Nations League |
| `interconfederacion` | Partido o serie entre campeones de dos confederaciones distintas, sin ciclo fijo | Finalissima |

**Datos de catálogo incluidos en la Misión 001:** fila `Amistosos Internacionales` (ver convención dedicada).

**Datos poblados en la Misión 006 (MS-006):** 10 competiciones internacionales relevantes para selecciones nacionales (`COMP-000002` a `COMP-000011`), verificadas mediante fuentes públicas ampliamente reconocidas (Wikipedia, UEFA.com, CAF Online, AFC, CONCACAF, CONMEBOL — ver `CHANGELOG.md` para el detalle de fuentes por competición). No se incluyen competiciones de clubes, categorías juveniles ni fútbol femenino — fuera del alcance actual del Modelo Santiago (predicción de partidos de selecciones absolutas masculinas). No se crean aún filas en `torneos.csv` para estas competiciones (ediciones específicas con fechas y sedes) — queda explícitamente diferido a una misión futura, conforme al alcance de MS-006.

**Nota sobre periodicidad variable:** algunas competiciones cambian de ciclo con el tiempo. La Copa Africana de Naciones (CAF) fue bienal hasta su edición 2027 inclusive; CAF anunció en diciembre de 2025 el paso a un ciclo cuatrienal a partir de 2028 para alinearse con la Eurocopa. Se almacena `periodicidad_anios = 4` por representar el ciclo vigente hacia el futuro, dejando esta nota como registro de la transición (evita invocar una migración de esquema para un campo que ya captura el estado más reciente y verificable).

---

## 11. `torneos.csv`

| Campo | Tipo | Clave | Justificación |
|---|---|---|---|
| `id_torneo` | STRING | PK | Integridad referencial (obligatorio en `partidos`, nunca nulo) |
| `id_competicion` | STRING | FK → `competiciones` | Relación obligatoria |
| `edicion` | STRING | | Trazabilidad/legibilidad temporal |
| `paises_organizadores` | STRING | | Insumo de Factores Externos (sede única vs. multisede afecta Localía, Variable 009) |
| `fecha_inicio` | DATE | | Delimita la ventana temporal de Rendimiento en el Torneo (Variable 002) |
| `fecha_fin` | DATE | | Idem |
| `formato` | STRING | | Contextualiza Índice de Caos (grupos + eliminación directa vs. liga) |
| `numero_selecciones_participantes` | INTEGER | | Contextualiza el nivel competitivo (vacío si `tipo` de la competición es `amistoso`) |

**Campo eliminado (decisión de esta misión):** `campeon_id_seleccion` — dato derivado de `partidos` (fila con `fase = final`), nunca almacenado.
**Restricciones:** `fecha_fin` ≥ `fecha_inicio`.
**Datos de catálogo incluidos en esta misión:** fila `TOR-2026-AMISTOSOS` (ver convención dedicada).
**Convención de `id_torneo` para "Eliminatorias Mundial FIFA" (fijada en `MS-015`):** `TOR-<año del Mundial>-ELIM-<CONFEDERACIÓN>` (ej. `TOR-2026-ELIM-CONMEBOL`) — una fila por confederación, no una sola fila para toda la competición `COMP-000003`, porque cada proceso clasificatorio real (CONMEBOL, UEFA, CONCACAF, AFC, CAF) tiene su propio calendario, formato y número de participantes, sin una sede ni un formato único que los agrupe. `paises_organizadores` usa la misma convención ya fijada para amistosos (`"N/A (sede variable, ver partidos.id_estadio)"`) para todo torneo sin una sede fija (clasificatorias; Nations League en su fase de liga).
**Datos poblados en la Misión MS-015:** 12 ediciones reales (13 filas de datos en total junto con `TOR-2026-AMISTOSOS`) — ver `CHANGELOG.md` para fuentes completas por torneo.

---

# Próximos pasos (fuera de esta misión)

- Misión futura: estadísticas individuales de jugador por partido (goles, asistencias, minutos jugados, tarjetas), explícitamente diferida por decisión de esta misión.
- Incorporación de datos reales validados desde `data/raw/` siguiendo el flujo de `docs/05-Base-de-Conocimiento.md`.
